﻿using System;

namespace Currency.Data
{
    public class Class1
    {
    }
}
